package com.nf.reader.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import android.util.Log;

/**
 * 该类主要存储系统变量
 * @author Administrator
 *
 */
public class Constants {
	public static final String SETTING_PREFERENCE_NAME = "SETTING_PREFERENCE";// 保存设置的share
	public static HashMap<String,String> map=new HashMap<String,String>();

}
